#include "../include/main.h"

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {
	pros::Controller master(pros::E_CONTROLLER_MASTER);
	pros::Motor Ldrive (1, pros::E_MOTOR_GEARSET_18, false);
	pros::Motor Rdrive (2, pros::E_MOTOR_GEARSET_18, false);
	pros::Motor Larm (3,pros::E_MOTOR_GEARSET_36, false);
	pros::Motor Rarm (4,pros::E_MOTOR_GEARSET_36, false);
	pros::Motor Puncher (5,pros::E_MOTOR_GEARSET_18, false);
	pros::Motor Claw (6,pros::E_MOTOR_GEARSET_18,false);
	pros::Motor ClawRotate (7,pros::E_MOTOR_GEARSET_18,false);
	pros::Motor Intake (8, pros::E_MOTOR_GEARSET_18,false);
	while (true) {
		pros::lcd::print(0,"%d %d %d", (pros::lcd::read_buttons() & LCD_BTN_LEFT) >> 2,
		                 (pros::lcd::read_buttons() & LCD_BTN_CENTER) >> 1,
		                 (pros::lcd::read_buttons() & LCD_BTN_RIGHT) >> 0);
		int left = master.get_analog(ANALOG_LEFT_Y);
		int right = master.get_analog(ANALOG_RIGHT_Y);
		int armdown = 0; //TODO
		int armup = 0; //TODO
		if(armdown == 1 && armup == 0){
			//arm down
		}
		else if(armdown == 0 && armup == 1){
			//arm up
		}
		else{
			//arm stop
		}

		Ldrive = left;
		Rdrive = right;

		pros::delay(20);
	}
}
